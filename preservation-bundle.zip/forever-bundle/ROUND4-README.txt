Offline survival bundle — round 4
Generated 2026-11-16.
Work: 劳动价值论是历史性范畴：当代价值危机 / The Labor Theory of Value as a Historical Category: The Contemporary Crisis of Value
Author: Didgeridoo (pen name). Licence: CC BY 4.0.
Status: open preprint, NOT peer reviewed.
Primary DOI: 10.5281/zenodo.24270266 | Concept DOI: 10.5281/zenodo.24269665
Verify this archive with preservation-bundle.zip.sha256 at the site root,
then verify every stable inner file with the bundled CHECKSUMS.sha256.
CHECKSUMS.sha256 covers immutable content assets only; regenerable inventories
(RO-Crate, IPFS CID list, TimeMap, health report, redundancy map, P2P manifest)
are excluded to avoid self-referential checksum cycles. Those files carry their
own verification, and the site root always holds the newest edition of each.
For P2P seeding and magnet links see P2P-MANIFEST.json / torrents.html at the site root.
Do not redistribute Figshare historical record 35018683 (early non-pseudonymous signature).
