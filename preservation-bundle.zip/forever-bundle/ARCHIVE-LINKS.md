# 公开存档与 DOI（2026-11-16 已真实提交）

作者：Didgeridoo　|　许可：CC BY 4.0　|　文件：paper.pdf（9 页，1,389,530 字节；正文一字未改，仅重写文档属性去标识化）

| 平台 | 标识 | 地址 | 状态 |
|---|---|---|---|
| **Zenodo（主 DOI）** | `10.5281/zenodo.24270266` | https://doi.org/10.5281/zenodo.24270266 | 已发布，CC BY 4.0，作者Didgeridoo，PDF 可下载 |
| **Figshare（干净记录）** | `10.6084/m9.figshare.35018998.v1` | https://doi.org/10.6084/m9.figshare.35018998.v1 | 已发布，作者 Didgeridoo；分类 Political economy and social change、CC BY 4.0 |
| **OSF** | 项目 `wubs2` | https://osf.io/wubs2/ | public=True，PDF 完整，描述中标注作者 |
| 在线阅读页 | — | https://wbapp-qjvohz0ip85p3s9mnjs8do.app.workbuddy.host/?sharecode=ZILGUJCJKG | 全文 + 9 页原稿影印 |
| GitHub | v1.0.0 Release | https://github.com/kiloiam/labor-value-theory-preprint/releases/tag/v1.0.0 | 版本快照，附 PDF |

## 全球分发台账

全部干净入口、CDN 副本、12 处 Wayback 永久快照、Software Heritage / OpenAIRE / IndexNow 状态与机器可读元数据清单，见
`DISTRIBUTION.md`、`distribution.html` 与 `PRESERVATION.md`。

## 建议引用格式

```
Didgeridoo. 劳动价值论是历史性范畴：当代价值危机[Z/OL]. Zenodo, 2026. https://doi.org/10.5281/zenodo.24270266.
```

```bibtex
@misc{didgeridoo2026ltv,
  author = {Didgeridoo},
  title  = {劳动价值论是历史性范畴：当代价值危机},
  year   = {2026},
  doi    = {10.5281/zenodo.24270266},
  howpublished = {Preprint, Zenodo},
  note   = {网络预发布，非期刊正式发表；CC BY 4.0}
}
```

## 重要说明

- 以上均为**网络预发布预印本**，无同行评审，**不等同于期刊正式发表**，不构成成果认定依据。
- DOI 解决的是可引用性与长期保存，不替代期刊评审。
- **Figshare 旧记录 `35018683` 已弃用**：其 v1/v2 为只读历史版本，页面作者字段与附件 PDF 文档属性仍含早期署名；该记录不在本表内，请勿引用或传播其版本链接。官方 `Take down request` 模板见 `FIGSHARE-TAKEDOWN-REQUEST.md`；该工单已由本人提交，等待 Figshare 团队处理。
- 目标期刊《中南大学学报(社会科学版)》只接受作者本人在 https://zndxsk.csu.edu.cn 的「作者在线投稿」系统提交，且明文禁止代投；投稿前须核实该刊预印本政策，并如实说明本稿已有公开记录与 DOI。


## 第三轮新增的正式记录

| 平台 | 标识 | 链接 | 说明 |
|---|---|---|---|
| Zenodo（永久保存包版本） | `10.5281/zenodo.24273568` | https://doi.org/10.5281/zenodo.24273568 | 含 34 文件离线包，作者 Didgeridoo，CC BY 4.0；概念 DOI `10.5281/zenodo.24269665` 现指向此版本 |
| GitHub Gist | 公开 gist | https://gist.github.com/kiloiam/d286d7f3b8ee3adf0e8f2ba0595f7ab7 | 纯文本全文 + 离线 HTML + 校验表 + 清单，Software Heritage 已存档 |
| GitHub Release | `v2.0.0` | https://github.com/kiloiam/labor-value-theory-preprint/releases/tag/v2.0.0 | 18 个不可变资产 |
| commit 固定永久链接 | `49a0fc7` | https://cdn.jsdelivr.net/gh/kiloiam/labor-value-theory-preprint@49a0fc78f5953c47add0a39e78c4b6bf0dac9c69/paper.pdf | 按提交 SHA 固定，不随分支变化 |

> 冗余地图：https://kiloiam.github.io/labor-value-theory-preprint/forever.html　|　副本清单：https://kiloiam.github.io/labor-value-theory-preprint/MIRRORS.md　|　校验：https://kiloiam.github.io/labor-value-theory-preprint/CHECKSUMS.sha256
