================================================================================
FOREVER README — 长期保存与恢复说明
劳动价值论是历史性范畴：当代价值危机 / Didgeridoo / CC BY 4.0 / 2026-11-16
================================================================================

这个文件存在的理由
--------------------------------------------------------------------------------
如果某一天 DOI 解析失效、网站下线、PDF 格式不再被识别、甚至没有浏览器可用，
只要还有人拿到本目录中的任意一个文件，就应该能重建这篇论文的全部内容。

因此本目录提供三种互不依赖的可读形态：

  1) PAPER-PLAINTEXT.txt   —— 纯 UTF-8 文本全文，无标记、无外部依赖，可直接打印。
  2) paper-standalone.html —— 单文件网页，内嵌全文、署名、许可与全部副本地址，
                              断网可用，不加载脚本 / 字体 / 图片。
  3) paper.pdf             —— 保留原排版的 9 页原稿（已去标识化）。

身份信息（重建时必须一并保留）
--------------------------------------------------------------------------------
  署名      : Didgeridoo（笔名，不披露真实身份）
  首发日期  : 2026-11-16
  许可      : CC BY 4.0  https://creativecommons.org/licenses/by/4.0/
  主 DOI    : 10.5281/zenodo.24270266
  概念 DOI  : 10.5281/zenodo.24269665（始终指向最新版本）
  第二 DOI  : 10.6084/m9.figshare.35018998.v1
  OSF       : https://osf.io/wubs2/
  规范网址  : https://kiloiam.github.io/labor-value-theory-preprint/
  状态      : 开放预印本，未经同行评审，不等同期刊正式发表

  paper.pdf     SHA-256 : 1bf85cf8bb0a91fe01738e875b360319180852fd0f0fe0aeb5ab628fd3d84c3a
  manuscript.md SHA-256 : 4be797a8719b418d3f58aee69a7f025c67ccb0d42e2c5dcacc85e3cd5ff8be6e

校验方法：sha256sum -c CHECKSUMS.sha256（或任意等价工具逐项比对）。

已登记的 16 处副本
--------------------------------------------------------------------------------
  [01] Zenodo (CERN / OpenAIRE)
       EU / Switzerland | DOI-registered open repository
       https://doi.org/10.5281/zenodo.24270266
  [02] Zenodo (CERN)
       EU / Switzerland | concept DOI (always resolves to latest version)
       https://doi.org/10.5281/zenodo.24269665
  [03] Figshare (Digital Science)
       UK | DOI-registered open repository
       https://doi.org/10.6084/m9.figshare.35018998.v1
  [04] Open Science Framework (Center for Open Science)
       US | open project storage with versioned files
       https://osf.io/wubs2/
  [05] GitHub Pages
       US | static full-text site
       https://kiloiam.github.io/labor-value-theory-preprint/
  [06] GitHub
       US | versioned git repository
       https://github.com/kiloiam/labor-value-theory-preprint
  [07] GitHub Releases
       US | immutable tagged release with binary assets
       https://github.com/kiloiam/labor-value-theory-preprint/releases/tag/v1.0.0
  [08] WorkBuddy hosted site
       CN | hosted reading page with 9 facsimile pages
       https://wbapp-qjvohz0ip85p3s9mnjs8do.app.workbuddy.host/?sharecode=ZILGUJCJKG
  [09] Software Heritage (UNESCO / Inria)
       FR / EU | permanent source-code archive with SWHID
       https://archive.softwareheritage.org/
  [10] Internet Archive Wayback Machine
       US | web time-capsule snapshots (12 + new captures)
       https://web.archive.org/web/20261116061932/https://kiloiam.github.io/labor-value-theory-preprint/
  [11] OpenAIRE
       EU | Europe-wide open scholarly index (already indexed)
       https://api.openaire.eu/search/publications?doi=10.5281/zenodo.24270266
  [12] DataCite
       international | DOI metadata registry
       https://commons.datacite.org/doi.org/10.5281/zenodo.24270266
  [13] jsDelivr global CDN
       multi-region | CDN edge copy
       https://cdn.jsdelivr.net/gh/kiloiam/labor-value-theory-preprint@main/paper.pdf
  [14] raw.githubusercontent.com
       US | raw file mirror
       https://raw.githubusercontent.com/kiloiam/labor-value-theory-preprint/main/paper.pdf
  [15] raw.githack.com
       multi-region | independent CDN mirror
       https://raw.githack.com/kiloiam/labor-value-theory-preprint/main/paper.pdf
  [16] gitcdn.link
       multi-region | independent CDN mirror
       https://gitcdn.link/cdn/kiloiam/labor-value-theory-preprint/main/paper.pdf

再发布规则
--------------------------------------------------------------------------------
全文以 CC BY 4.0 开放。任何人都可以复制、翻译、打印、重新托管、纳入新的资料库，
无需额外授权；只需保留署名 "Didgeridoo"、许可声明与原始 DOI。
多语种短摘要（abstracts.json）仅供检索发现，学术引用请以中文原文与作者英文摘要为准。

诚实的边界
--------------------------------------------------------------------------------
没有任何数字系统能承诺「人类文明灭亡为止不消失」。这套设计能做的是：
把副本分散到尽可能多的独立机构与法域，让单点失效、单点审查、单点格式淘汰
都不会同时摧毁全部内容；并让每个副本自带其余副本的地址，便于后来者重新汇聚。
真正的长期保存最终依赖持续存在的读者与机构——所以最可靠的一步，是把
PAPER-PLAINTEXT.txt 再复制到你自己的设备、你所在的图书馆或你信任的存档机构。

请勿传播：Figshare 旧记录 35018683 的 v1 / v2 历史版本（含早期署名，下架工单处理中）。
================================================================================
